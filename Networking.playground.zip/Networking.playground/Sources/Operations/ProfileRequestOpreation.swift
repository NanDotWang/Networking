import Foundation

/// Contrived example class that makes a HEAD request for a given URL. Its a
/// concrete subclass of AsyncOperation, which makes it easy to chain it
/// together with other (NS)Operations via standard dependencies:
///
///     let head = HeadRequestOperation(url: u) { result in
///         switch (result) {...}
///     }
///     let finish = BlockOperation {...}
///     finish.addDependency(head)
///
public class ProfileRequestOperation: AsyncOperation {

    /// request object
    public let request: ProfileRequest

    /// holding the result passing through callback
    private var result: Result = .error(nil)

    /// initialize opreation without callback
    public init(with request: ProfileRequest) {
        self.request = request
        super.init()
    }

    /// initialize operation with callback
    public init(with request: ProfileRequest, resultHandler: @escaping (Result) -> Void) {
        self.request = request
        super.init()
        addCompletionHandler { [weak self] in
            let result = self?.result ?? .error(nil)
            resultHandler(result)
        }
    }

    /// execute request
    override public func execute(finish: @escaping () -> Void) {
        self.request.send() { (result) in
            self.result = result
            print("ProfileRequestOperation Done.")
            /// must call finish() to finish the async operation
            finish()
        }
    }
}
